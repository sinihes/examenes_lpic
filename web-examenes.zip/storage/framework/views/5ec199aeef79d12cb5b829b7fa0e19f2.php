<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h2 class="mb-0">RESULTADO</h2>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <p><strong>Categoría:</strong> <?php echo e($result->category); ?></p>
                </div>
                <div class="col-md-4">
                    <p><strong>Puntuación:</strong>
                        <span class="badge bg-<?php echo e($result->score >= ($result->total/2) ? 'success' : 'danger'); ?>">
                            <?php echo e($result->score); ?> / <?php echo e($result->total); ?>

                        </span>
                    </p>
                </div>
                <div class="col-md-4">
                    <p><strong>Fecha:</strong> <?php echo e($result->created_at->format('d/m/Y H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4 border-<?php echo e($q['is_correct'] ? 'success' : 'danger'); ?>">
            <div class="card-header bg-light">
                <h5 class="mb-0">❓ Pregunta <?php echo e($loop->iteration); ?></h5>
            </div>
            <div class="card-body">
                <p class="lead"><?php echo e($q['question_text']); ?></p>

                <?php if(isset($q['options']) && in_array($q['question_type'], ['single', 'multiple'])): ?>
                    <div class="options-container mb-3">
                        <?php $__currentLoopData = $q['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isUserAnswer = false;
                                if ($q['question_type'] === 'single') {
                                    $isUserAnswer = isset($q['user_answer']) && $opt['label'] === $q['user_answer'];
                                } elseif ($q['question_type'] === 'multiple') {
                                    $isUserAnswer = isset($q['user_answer']) && in_array($opt['label'], (array) $q['user_answer']);
                                }

                                $isCorrectOption = $opt['correct'] ?? false;

                                $optionClass = '';
                                if ($isUserAnswer && $isCorrectOption) {
                                    $optionClass = 'bg-success bg-opacity-10';
                                } elseif ($isUserAnswer && !$isCorrectOption) {
                                    $optionClass = 'bg-danger bg-opacity-10';
                                } elseif (!$isUserAnswer && $isCorrectOption) {
                                    $optionClass = 'border-success';
                                }
                            ?>
                            <div class="p-2 mb-2 border rounded <?php echo e($optionClass); ?>">
                                <div class="form-check">
                                    <input class="form-check-input" type="<?php echo e($q['question_type'] === 'single' ? 'radio' : 'checkbox'); ?>"
                                           id="opt-<?php echo e($loop->parent->iteration); ?>-<?php echo e($loop->iteration); ?>"
                                           <?php if($isUserAnswer): ?> checked <?php endif; ?> disabled>
                                    <label class="form-check-label" for="opt-<?php echo e($loop->parent->iteration); ?>-<?php echo e($loop->iteration); ?>">
                                        <strong><?php echo e(strtolower($opt['label'])); ?>.</strong> <?php echo e($opt['text']); ?>

                                        <?php if($isUserAnswer && $isCorrectOption): ?>
                                            <span class="text-success ms-2">✔ Correcto</span>
                                        <?php elseif($isUserAnswer && !$isCorrectOption): ?>
                                            <span class="text-danger ms-2">✘ Incorrecto</span>
                                        <?php elseif(!$isUserAnswer && $isCorrectOption): ?>
                                            <span class="text-success ms-2">(Respuesta correcta)</span>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="alert alert-success">
                        <strong>Respuesta correcta:</strong>
                        <?php
                            $correctOptions = collect($q['options'])->filter(function($o) {
                                return isset($o['correct']) && $o['correct'];
                            });
                            $correctAnswers = $correctOptions->map(function($o) {
                                return strtolower($o['label']) . '. ' . $o['text'];
                            })->implode(', ');
                        ?>
                        <?php echo e($correctAnswers); ?>

                    </div>

                <?php elseif($q['question_type'] === 'text'): ?>
                    <div class="mb-3">
                        <p class="mb-1"><strong>Tu respuesta:</strong></p>
                        <div class="p-2 border rounded <?php echo e($q['is_correct'] ? 'border-success bg-success bg-opacity-10' : 'border-danger bg-danger bg-opacity-10'); ?>">
                            <?php echo e($q['user_answer'] ?? '(Sin respuesta)'); ?>

                        </div>
                    </div>
                    <div class="alert alert-success">
                        <strong>Respuesta correcta:</strong> <?php echo e($q['correct_answer'] ?? 'No disponible'); ?>

                    </div>
                <?php endif; ?>

                <?php if(!empty($q['feedback'])): ?>
                    <div class="alert alert-info mt-3">
                        <strong>📌 Retroalimentación:</strong> <?php echo e($q['feedback']); ?>

                    </div>
                <?php endif; ?>

                <div class="mt-3">
                    <span class="badge bg-<?php echo e($q['is_correct'] ? 'success' : 'danger'); ?>">
                        <?php echo e($q['is_correct'] ? '✅ Correcta' : '❌ Incorrecta'); ?>

                    </span>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex justify-content-between mt-4">
        <a href="<?php echo e(route('exam.statistics', ['category' => $result->category, 'examId' => $result->exam_id])); ?>"
           class="btn btn-outline-secondary">
            ← Volver a estadísticas
        </a>
        <a href="<?php echo e(route('exam.take', ['category' => $result->category, 'examId' => $result->exam_id])); ?>"
           class="btn btn-primary">
            Intentar de nuevo
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sinihes/Escritorio/web-lpic/resources/views/exam/result.blade.php ENDPATH**/ ?>