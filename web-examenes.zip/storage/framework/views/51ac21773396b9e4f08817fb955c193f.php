<div class="container mx-auto py-8">
    <div class="bg-white p-6 rounded-lg shadow">
        <h1 class="text-2xl font-bold text-indigo-600 mb-4">
            Resultados: <?php echo e($exam['title']); ?>

        </h1>

        <div class="mb-6">
            <div class="flex items-center">
                <span class="text-4xl font-bold <?php echo e($passed ? 'text-green-500' : 'text-red-500'); ?>">
                    <?php echo e($score); ?>/<?php echo e($total); ?>

                </span>
                <span class="ml-4 text-lg">
                    <?php echo e(number_format(($score/$total)*100, 2)); ?>%
                </span>
            </div>
        </div>

        <?php if(count($incorrect) > 0): ?>
        <div class="mt-8">
            <h3 class="text-lg font-semibold mb-2">Preguntas incorrectas:</h3>
            <?php $__currentLoopData = $incorrect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4 p-4 bg-red-50 rounded">
                <p class="font-medium"><?php echo e($item['question']); ?></p>
                <p class="text-sm text-red-600">Respuesta correcta: <?php echo e($item['correct_answer']); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/sinihes/Escritorio/web-lpic/resources/views/exams/statistics.blade.php ENDPATH**/ ?>