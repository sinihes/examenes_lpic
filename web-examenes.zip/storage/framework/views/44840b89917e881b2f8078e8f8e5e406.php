<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-3xl font-bold text-indigo-600 mb-4"><?php echo e($exam->title); ?></h1>

    <div class="mt-6">
    <a href="<?php echo e(route('exam.take', ['category' => $category, 'examId' => $exam->id])); ?>"
       class="">
        Reintentar el cuestionario
    </a>
    </div>

    <div class="bg-white shadow rounded-lg p-6 mb-6">
        <h2 class="text-xl font-semibold mb-2">Requisitos de finalización</h2>
        <ul class="list-disc list-inside text-gray-700">
            <li><strong>Hecho:</strong> Ver</li>
            <li><strong>Método de calificación:</strong> Calificación más alta</li>
        </ul>
    </div>

    <div class="bg-white shadow rounded-lg p-6">
        <h2 class="text-xl font-semibold mb-4">Resumen de sus intentos previos</h2>

        <?php if($results->isEmpty()): ?>
            <p class="text-gray-500">Aún no ha realizado este examen.</p>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100 text-left text-sm font-medium text-gray-700">
                    <tr>
                        <th class="px-4 py-2">Intento</th>
                        <th class="px-4 py-2">Estado</th>
                        <th class="px-4 py-2">Puntos</th>
                        <th class="px-4 py-2">Calificación</th>
                        <th class="px-4 py-2">Enviado</th>
                        <th class="px-4 py-2">Revisión</th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-800">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?php echo e($index + 1); ?></td>
                        <td class="px-4 py-2">Finalizado</td>
                        <td class="px-4 py-2"><?php echo e($result->score); ?> / <?php echo e($result->total); ?></td>
                        <td class="px-4 py-2"><?php echo e(number_format(($result->score / $result->total) * 10, 2)); ?></td>
                        <td class="px-4 py-2"><?php echo e($result->created_at->translatedFormat('l, j \\d\\e F \\d\\e Y, H:i')); ?></td>
                        <td class="px-4 py-2">
                            <a href="#" class="text-indigo-600 hover:underline">Revisión</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4 text-sm text-gray-600">
            <strong>Calificación más alta:</strong>
            <?php echo e(number_format(($results->max('score') / $results->first()->total) * 10, 2)); ?> / 10,00
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sinihes/Escritorio/web-lpic/resources/views/exams/show.blade.php ENDPATH**/ ?>