<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <!-- Encabezado -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 fw-bold text-primary mb-0">
            <i class="fas fa-clipboard-list me-2"></i>Exámenes <?php echo e($course); ?>

        </h2>
        <span class="badge bg-primary">
            <?php echo e(count($exams)); ?> exámenes disponibles
        </span>
    </div>
    <!-- Lista de exámenes -->
    <div class="list-group">
        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
            <div class="d-flex align-items-center">
                <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                    <i class="fas fa-file-alt text-primary"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold"><?php echo e($exam->title); ?></h6>
                    <small class="text-muted"><?php echo e(count($exam->questions)); ?> preguntas</small>
                </div>
            </div>
            <a href="/exam/<?php echo e($exam->category); ?>/<?php echo e($exam->id); ?>"
               class="btn btn-sm btn-outline-primary">
               <i class="fas fa-play me-1"></i>Iniciar
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Estadísticas -->
    <div class="mt-4 pt-3 border-top">
        <div class="d-flex align-items-center">
            <i class="fas fa-chart-line text-muted me-2"></i>
            <small class="text-muted">
                Tienes <?php echo e($exam->totalIntentos); ?> intentos registrados
            </small>
        </div>
    </div>
</div>

<style>
    .list-group-item {
        transition: all 0.2s;
        border-left: 3px solid transparent;
    }
    .list-group-item:hover {
        background-color: #f8f9fa;
        border-left-color: #0d6efd;
    }
    .btn-outline-primary {
        transition: all 0.2s;
    }
    .btn-outline-primary:hover {
        background-color: #0d6efd;
        color: white;
    }
</style>

<!-- Iconos de Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sinihes/Escritorio/web-lpic/resources/views/pages/lpic1.blade.php ENDPATH**/ ?>