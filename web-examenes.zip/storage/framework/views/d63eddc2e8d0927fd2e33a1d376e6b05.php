<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h2 fw-bold text-primary mb-2"><?php echo e($exams->title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="#"><?php echo e($category); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Resultados</li>
                </ol>
            </nav>
        </div>
        <a href="<?php echo e(route('exam.take', ['category' => $category, 'examId' => $examId])); ?>"
           class="btn btn-primary">
           <i class="fas fa-redo me-2"></i>Reintentar examen
        </a>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                            <i class="fas fa-chart-line text-primary"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Mejor calificación</h6>
                            <p class="h3 fw-bold mb-0"><?php echo e(number_format($highestNote, 2)); ?>/10.00</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-info bg-opacity-10 p-3 rounded-circle me-3">
                            <i class="fas fa-list-ol text-info"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Total intentos</h6>
                            <p class="h3 fw-bold mb-0"><?php echo e(count($results)); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle me-3">
                            <i class="fas fa-question-circle text-success"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Preguntas</h6>
                            <p class="h3 fw-bold mb-0"><?php echo e($results->first()->total ?? 0); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Attempts Table -->
    <div class="card border-0 shadow">
        <div class="card-header bg-white border-0 py-3">
            <h5 class="mb-0"><i class="fas fa-history me-2"></i>Historial de intentos</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col" class="ps-4">Intento</th>
                            <th scope="col">Realizado</th>
                            <th scope="col">Preguntas</th>
                            <th scope="col">Calificación/10.00</th>
                            <th scope="col" class="text-end pe-4">Revisión</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row" class="ps-4"><?php echo e($result->id); ?></th>
                            <td><?php echo e($result->created_at->format('d/m/Y H:i')); ?></td>
                            <td><?php echo e($result->total); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e(($result->score/$result->total)*10 >= 5 ? 'success' : 'danger'); ?>">
                                    <?php echo e(number_format(($result->score/$result->total)*10, 2)); ?>

                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <a href="<?php echo e(route('exam.revision', ['category' => $category, 'revisionId' => $result->id])); ?>"
                                   class="btn btn-sm btn-outline-primary">
                                   <i class="fas fa-eye me-1"></i>Ver
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    .card {
        border-radius: 10px;
        transition: transform 0.3s ease;
    }
    .card:hover {
        transform: translateY(-3px);
    }
    .table-hover tbody tr:hover {
        background-color: rgba(13, 110, 253, 0.05);
    }
    .breadcrumb {
        background-color: transparent;
        padding: 0;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sinihes/Escritorio/web-lpic/resources/views/exam/statistics.blade.php ENDPATH**/ ?>