<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-6"><?php echo e($exam->title); ?></h1>

    <form method="POST" action="<?php echo e(route('exam.submit', ['category' => $category, 'examId' => $exam->id])); ?>">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-6 p-4 border rounded shadow-sm">
                <p class="font-semibold mb-2"><?php echo e($loop->iteration); ?>. <?php echo e($question->question); ?></p>

                <?php if($question->type === 'single'): ?>
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="block cursor-pointer mb-1">
                            <input type="radio" name="q_<?php echo e($question->id); ?>" value="<?php echo e($option->label); ?>" class="mr-2">
                            <?php echo e(strtoupper($option->label)); ?>. <?php echo e($option->text); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php elseif($question->type === 'multiple'): ?>
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="block cursor-pointer mb-1">
                            <input type="checkbox" name="q_<?php echo e($question->id); ?>[]" value="<?php echo e($option->label); ?>" class="mr-2">
                            <?php echo e(strtoupper($option->label)); ?>. <?php echo e($option->text); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php elseif($question->type === 'text'): ?>
                    <input type="text" name="q_<?php echo e($question->id); ?>" class="border p-2 rounded w-full" />
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded">
            Enviar respuestas
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sinihes/Escritorio/web-lpic/resources/views/exams/take.blade.php ENDPATH**/ ?>